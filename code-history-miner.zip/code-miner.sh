#!/bin/sh

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
CLASSPATH=":$DIR/lib/*"
export CLASSPATH

JVM_ARGS=-Xmx2048m
MAIN_CLASS_NAME=codemining.web.cli.WebMain

java $JVM_ARGS $MAIN_CLASS_NAME ${1+"$@"}
