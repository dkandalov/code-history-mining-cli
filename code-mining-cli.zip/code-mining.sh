#!/bin/sh

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
CLASSPATH=":$DIR/lib/*"
export CLASSPATH

MAIN_CLASS_NAME=codemining.cli.Main

java $MAIN_CLASS_NAME $@
