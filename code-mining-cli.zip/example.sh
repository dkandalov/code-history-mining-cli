#!/bin/sh

git clone https://github.com/junit-team/junit
cd junit

../code-mining.sh grab --from 01/01/2012 --to 01/01/2014
../code-mining.sh visualize --csv junit.csv
