Code history mining CLI
=======================

This is a command line application to analyze and visualize project code history.

To see command line options run code-mining.sh or .bat without any parameters.

For any problems or questions please [create an issue on github](https://github.com/dkandalov/code-history-mining-cli/issues/new).
See http://codehistorymining.com for more details.
